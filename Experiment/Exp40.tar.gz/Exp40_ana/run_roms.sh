cd /home/aruba/vol2/ipasmans/Exp/Exp35/Exp40_ana/
export OMP_NUM_THREADS=24
/home/aruba/vol2/ipasmans/Bin_Exp35//oceanOCR < /home/aruba/vol2/ipasmans/Exp/Exp35/Exp40_ana/ocean.in > /home/aruba/vol2/ipasmans/Exp/Exp35/Exp40_ana/ocean.out
